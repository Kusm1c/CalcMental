package com.example.AppLelHar.database;

import android.content.Context;

public class ComputeBaseHelper extends  DataBaseHelper{


        public ComputeBaseHelper(Context context){ super(context,"CalculGame",1); }

    @Override
    protected String getCreationSql() {
        return "CREATE TABLE IF NOT EXISTS bestScore("
                + "id" + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + CalculDAO.cleBestEasy + " INTEGER NOT NULL, "
                + CalculDAO.cleBestMedium + " INTEGER NOT NULL, "
                + CalculDAO.cleBestHard + " INTEGER NOT NULL "
                + ")";
    }

    @Override
    protected String getDeleteSql() {
        return null;
    }
}

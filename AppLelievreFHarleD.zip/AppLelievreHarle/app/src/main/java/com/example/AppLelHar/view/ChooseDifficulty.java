package com.example.AppLelHar.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.AppLelHar.R;

public class ChooseDifficulty extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose_difficulty);
        Button Easy = findViewById(R.id.Easy);
        Easy.setOnClickListener(view -> ouvreEasy());
        Button Medium = findViewById(R.id.Medium);
        Medium.setOnClickListener((view -> ouvreMedium()));
        Button Hard = findViewById(R.id.Hard);
        Hard.setOnClickListener(view -> ouvreHard());
    }

    private void ouvreHard() {
        Intent intent = new Intent(this, CalculActivityHard.class);
        startActivity(intent);
    }

    private void ouvreMedium() {
        Intent intent = new Intent(this, CalculActivityMedium.class);
        startActivity(intent);
    }

    private void ouvreEasy() {
        Intent intent = new Intent(this, CalculActivity.class);
        startActivity(intent);
    }
}

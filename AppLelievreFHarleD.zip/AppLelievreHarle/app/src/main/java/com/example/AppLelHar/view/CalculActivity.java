package com.example.AppLelHar.view;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.AppLelHar.Service.CalculService;
import com.example.AppLelHar.database.CalculDAO;
import com.example.AppLelHar.database.ComputeBaseHelper;
import com.example.AppLelHar.models.Entities.Calcul;
import com.example.AppLelHar.R;

import java.util.Random;

public class CalculActivity extends AppCompatActivity {

    private TextView textViewcalcule;
    private TextView textViewAffiche;
    private TextView scoreTxt;
    private TextView bestScoreTxt;
    private Long Number = 0L;
    private Long RandomNum1, RandomNum2;
    private Long borneHaute = 99999L;
    private int Best = 0;
    private int BestScore = -1;
    private CalculService calculService;
    private Random rand = new Random();
    long leftLimit = 1L;
    long rightLimit = 10L;
    private int chosesign = 0;
    private String sign = "";
    private Long result  = 0L;
    private Calcul calcul = new Calcul();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calcul);
        textViewcalcule = findViewById(R.id.viewCalc);
        textViewAffiche = findViewById(R.id.viewCalc2);
        calculService = new CalculService(new CalculDAO(new ComputeBaseHelper(this)));
        Button button_0 = findViewById(R.id.button_n0);
        button_0.setOnClickListener(view -> ajouterNombre(0));
        Button button_1 = findViewById(R.id.button_n1);
        button_1.setOnClickListener(view -> ajouterNombre(1));
        Button button_2 = findViewById(R.id.button_n2);
        button_2.setOnClickListener(view -> ajouterNombre(2));
        Button button_3 = findViewById(R.id.button_n3);
        button_3.setOnClickListener(view -> ajouterNombre(3));
        Button button_4 = findViewById(R.id.button_n4);
        button_4.setOnClickListener(view -> ajouterNombre(4));
        Button button_5 = findViewById(R.id.button_n5);
        button_5.setOnClickListener(view -> ajouterNombre(5));
        Button button_6 = findViewById(R.id.button_n6);
        button_6.setOnClickListener(view -> ajouterNombre(6));
        Button button_7 = findViewById(R.id.button_n7);
        button_7.setOnClickListener(view -> ajouterNombre(7));
        Button button_8 = findViewById(R.id.button_n8);
        button_8.setOnClickListener(view -> ajouterNombre(8));
        Button button_9 = findViewById(R.id.button_n9);
        button_9.setOnClickListener(view -> ajouterNombre(9));
        Button button_10 = findViewById(R.id.bouton_confirmer);
        button_10.setOnClickListener(view -> verifcalcul());
        Button button_11 = findViewById(R.id.button_n11);
        button_11.setOnClickListener(view -> videtextview());
        Button button_12 = findViewById(R.id.negative_button);
        button_12.setOnClickListener(view -> makeItNegative());
        scoreTxt = findViewById(R.id.ScoreTxt);
        scoreTxt.setText("Score: 0");
        bestScoreTxt = findViewById(R.id.BestScoreTxt);
        if (calculService.getBestEasy()!=null)
            bestScoreTxt.setText("Best: " + calculService.getBestEasy());
        else
            bestScoreTxt.setText("Best: 0");

        bestScoreTxt = findViewById(R.id.BestScoreTxt);
        generateRandomCalcul();
    }

    private void makeItNegative() {
        Number = -Number;
        majTextView();
    }

    private void ajouterNombre(Integer valeur) {

        if (Number * 10 + valeur > borneHaute) {
            Toast.makeText(this, getString(R.string.message_valeur_trop_grande), Toast.LENGTH_SHORT).show();
        } else{
            Number = Number * 10 + valeur;
        }
        majTextView();
    }

    private void majTextView(){
        String valeurAfficher ="";
        valeurAfficher = Number.toString();
        textViewAffiche.setText(valeurAfficher);
    }

    @SuppressLint("SetTextI18n")
    private void generateRandomCalcul() {
        RandomNum1 = leftLimit + (long) (Math.random() * (rightLimit - leftLimit));
        RandomNum2 = leftLimit + (long) (Math.random() * (rightLimit - leftLimit));
        chosesign = rand.nextInt(3);
        switch (chosesign){
            case 0:
                sign = "+";
                result = RandomNum1 + RandomNum2;
                break;
            case 1:
                sign = "-";
                result = RandomNum1 - RandomNum2;
                break;
            case 2:
                sign = "*";
                result = RandomNum1 * RandomNum2;
                break;
        }
        textViewcalcule.setText(RandomNum1 + " " + sign + " " +RandomNum2);
        videtextview();
    }

    private void verifcalcul(){
        if (result != Number){
            Toast.makeText(this,R.string.message_valeur_fausse,Toast.LENGTH_SHORT).show();
            calcul.setBestEasy(Best);
            calcul.setBestMedium(0);
            calcul.setBestHard(0);
            calculService.storeInOb(calcul);
            Intent intent = new Intent(this, Last_Compute.class);
            intent.putExtra("bestEasy",Best);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this,R.string.message_valeur_bonne,Toast.LENGTH_SHORT).show();
            textViewcalcule.setText("");
            generateRandomCalcul();
            Best+=1;
            majScore();

        }
    }

    private void majScore() {
        scoreTxt.setText("Score: " + Best + "");
        if (calculService.getBestEasy()!=null) {
            if (calculService.getBestEasy() < Best)
                bestScoreTxt.setText("Score: " + Best + "");
        }
    }

    private boolean videtextview() {
        textViewAffiche.setText("");
        Number = 0L;
        return true;
    }

}
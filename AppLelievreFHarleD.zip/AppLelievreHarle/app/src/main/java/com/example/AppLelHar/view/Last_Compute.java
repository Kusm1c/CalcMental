package com.example.AppLelHar.view;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.example.AppLelHar.R;
import com.example.AppLelHar.Service.CalculService;
import com.example.AppLelHar.database.CalculDAO;
import com.example.AppLelHar.database.ComputeBaseHelper;


public class Last_Compute extends AppCompatActivity {
    private Integer bestEasy;
    private Integer bestMedium;
    private Integer bestHard;
    private Integer savedBestEasy=-69;
    private Integer savedBestMedium=-69;
    private Integer savedBestHard=-69;
    private CalculService calculService;


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_last_compute);
        calculService = new CalculService(new CalculDAO(new ComputeBaseHelper(this)));
        Button button_precedent = findViewById(R.id.button_precedent);
        button_precedent.setOnClickListener(view -> retourneAuPrecedent());
        TextView bestEasyTxt = findViewById(R.id.bestEasyBox);
        TextView bestMediumTxt = findViewById(R.id.bestMediumBox);
        TextView bestHardTxt = findViewById(R.id.bestHardBox);
        Intent intent = getIntent();
        bestEasy = intent.getIntExtra("bestEasy",-69);
        bestMedium = intent.getIntExtra("bestMedium",-69);
        bestHard = intent.getIntExtra("bestHard",-69);
        savedBestEasy = calculService.getBestEasy();
        savedBestMedium = calculService.getBestMedium();
        savedBestHard = calculService.getBestHard();
        if (bestEasy>savedBestEasy){
            bestEasyTxt.setText("Best: " + bestEasy);
        } else {
            bestEasyTxt.setText("Best: " + savedBestEasy);
        }

        if (bestMedium>savedBestMedium){
            bestMediumTxt.setText("Best: " + bestMedium);
        } else {
            bestMediumTxt.setText("Best: " + savedBestMedium);
        }

        if (bestHard>savedBestHard){
            bestHardTxt.setText("Best: " + bestHard);
        } else {
            bestHardTxt.setText("Best: " + savedBestHard);
        }


    }

    private void retourneAuPrecedent() {
        finish();
    }
}
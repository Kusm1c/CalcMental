package com.example.AppLelHar.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.example.AppLelHar.R;

public class MainActivity extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button boutton_calculer = findViewById(R.id.boutton_calculer);
        boutton_calculer.setOnClickListener(view -> ouvreActiviteCalculer());
        Button Last_Compute_button = findViewById(R.id.Last_Compute_button);
        Last_Compute_button.setOnClickListener(view -> ouvreLast_Compute());
    }

    private void ouvreLast_Compute() {
        Intent intent = new Intent(this, Last_Compute.class);
        startActivity(intent);
    }

    private void ouvreActiviteCalculer() {
        Intent intent = new Intent(this, ChooseDifficulty.class);
        startActivity(intent);
    }


}
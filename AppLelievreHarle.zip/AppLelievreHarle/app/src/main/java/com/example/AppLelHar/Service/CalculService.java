package com.example.AppLelHar.Service;

import android.database.sqlite.SQLiteDatabase;

import com.example.AppLelHar.models.Entities.Calcul;
import com.example.AppLelHar.database.CalculDAO;

public class CalculService {
    private CalculDAO calculDAO;

    public CalculService(CalculDAO calculDAO) {
        this.calculDAO = calculDAO;
    }

    public Long getCalculCount() {
        return calculDAO.count();
    }

    public Integer getBestEasy() { return calculDAO.leBestEasy(); }

    public Integer getBestMedium() { return calculDAO.leBestMedium(); }

    public Integer getBestHard() { return calculDAO.leBestHard(); }

    public void storeInOb(Calcul calcul) {
        calculDAO.create(calcul);
    }
}

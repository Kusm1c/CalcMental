package com.example.AppLelHar.models.Entities;

public abstract  class BaseEntity {
    public long id;
}
